import aiosqlite
import hashlib
import secrets
import datetime
import os

DATABASE = "database.db"
SECRET_SALT = os.environ.get("SECRET_SALT")

if not SECRET_SALT:
    raise ValueError("SECRET_SALT environment variable not set. Please configure it in Replit Secrets.")

async def get_db():
    """Return a new async SQLite connection with dictionary row factory."""
    db = await aiosqlite.connect(DATABASE)
    db.row_factory = aiosqlite.Row
    return db

async def get_db_connection():
    """Get a fresh database connection for use in endpoints."""
    return await aiosqlite.connect(DATABASE)

async def init_db():
    """Create tables for users, tokens, and pro formas if they don't exist."""
    db = await aiosqlite.connect(DATABASE)
    db.row_factory = aiosqlite.Row
    try:
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                subscription TEXT DEFAULT 'free',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS tokens (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                expires_at TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS proformas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                data TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )
        
        # Add subscription column if it doesn't exist (for migration)
        try:
            await db.execute("ALTER TABLE users ADD COLUMN subscription TEXT DEFAULT 'free'")
        except aiosqlite.OperationalError:
            pass  # Column already exists
        
        # Add created_at columns if they don't exist (for migration)
        try:
            await db.execute("ALTER TABLE users ADD COLUMN created_at TEXT DEFAULT CURRENT_TIMESTAMP")
        except aiosqlite.OperationalError:
            pass
        
        try:
            await db.execute("ALTER TABLE tokens ADD COLUMN created_at TEXT DEFAULT CURRENT_TIMESTAMP")
        except aiosqlite.OperationalError:
            pass
        
        try:
            await db.execute("ALTER TABLE proformas ADD COLUMN updated_at TEXT DEFAULT CURRENT_TIMESTAMP")
        except aiosqlite.OperationalError:
            pass

        await db.commit()
    finally:
        await db.close()

def hash_password(password: str) -> str:
    """Hash a plaintext password using SHA-256 and the configured salt."""
    return hashlib.sha256((password + SECRET_SALT).encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    """Compare a plaintext password against its stored hash."""
    return hash_password(password) == hashed

async def create_token(db: aiosqlite.Connection, user_id: int) -> str:
    """Generate a random bearer token, persist it, and return it."""
    token = secrets.token_hex(32)
    expires_at = (datetime.datetime.utcnow() + datetime.timedelta(hours=24)).isoformat()
    await db.execute(
        "INSERT INTO tokens (token, user_id, expires_at) VALUES (?, ?, ?)",
        (token, user_id, expires_at),
    )
    await db.commit()
    return token

async def cleanup_expired_tokens():
    """Remove expired tokens from the database."""
    async with await get_db() as db:
        current_time = datetime.datetime.utcnow().isoformat()
        await db.execute("DELETE FROM tokens WHERE expires_at < ?", (current_time,))
        await db.commit()
