import json
import logging
import os
from typing import Dict, List, Any, Optional
from google import genai
from google.genai import types
from pydantic import BaseModel

# Initialize Gemini client
client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY", "default_key"))

class OptimizationSuggestion(BaseModel):
    parameter: str
    current_value: float
    suggested_value: float
    change_percentage: float
    rationale: str
    impact_description: str

class OptimizationResponse(BaseModel):
    overall_assessment: str
    suggestions: List[OptimizationSuggestion]
    risk_analysis: str
    confidence_score: float

class FinancialAnalysisService:
    """Service for AI-powered financial analysis using Gemini"""
    
    @staticmethod
    async def chat_with_context(message: str, user_proformas: List[Dict]) -> str:
        """
        Context-aware chatbot that can analyze user's pro forma documents
        """
        try:
            # Prepare context from user's pro formas
            context = "User's Pro Forma Data:\n"
            if user_proformas:
                for i, proforma in enumerate(user_proformas):
                    context += f"\nPro Forma {i+1} (Created: {proforma.get('created_at', 'Unknown')}):\n"
                    data = proforma.get('data', {})
                    for key, value in data.items():
                        context += f"  {key}: {value}\n"
            else:
                context += "No pro forma data available.\n"
            
            system_prompt = """You are an expert financial advisor and analyst specializing in pro forma financial statements. 
            You help users understand their financial projections, identify risks and opportunities, and provide actionable advice.
            
            Guidelines:
            - Analyze the user's specific pro forma data when available
            - Provide clear, actionable financial advice
            - Explain financial concepts in accessible terms
            - Identify potential risks and opportunities
            - Use specific numbers from their data when relevant
            - If no data is available, provide general financial guidance
            
            Always be professional, accurate, and helpful."""
            
            prompt = f"{context}\n\nUser Question: {message}\n\nPlease provide a comprehensive response based on the user's pro forma data and question."
            
            response = client.models.generate_content(
                model="gemini-2.5-pro",
                contents=[
                    types.Content(role="user", parts=[types.Part(text=prompt)])
                ],
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    temperature=0.7,
                    max_output_tokens=1000
                )
            )
            
            return response.text or "I apologize, but I'm unable to process your request at the moment. Please try again."
            
        except Exception as e:
            logging.error(f"AI chat error: {e}")
            return f"I'm experiencing technical difficulties. Please try again later. Error: {str(e)}"
    
    @staticmethod
    async def optimize_proforma(proforma_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        AI-powered pro forma optimization with detailed suggestions
        """
        try:
            # Prepare the pro forma data for analysis
            data_summary = "Pro Forma Financial Data:\n"
            for key, value in proforma_data.items():
                data_summary += f"{key}: {value}\n"
            
            system_prompt = """You are a senior financial analyst specializing in pro forma optimization. 
            Analyze the provided pro forma data and provide specific, actionable optimization suggestions.
            
            For each suggestion, provide:
            1. The parameter to optimize
            2. Current and suggested values
            3. Percentage change
            4. Detailed rationale
            5. Impact description
            
            Also provide:
            - Overall assessment of the financial position
            - Risk analysis
            - Confidence score (0.0 to 1.0)
            
            Focus on realistic, implementable improvements that will enhance financial performance."""
            
            prompt = f"{data_summary}\n\nPlease analyze this pro forma and provide optimization suggestions in JSON format."
            
            response = client.models.generate_content(
                model="gemini-2.5-pro",
                contents=[
                    types.Content(role="user", parts=[types.Part(text=prompt)])
                ],
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    response_mime_type="application/json",
                    response_schema=OptimizationResponse,
                    temperature=0.3
                )
            )
            
            if response.text:
                optimization_data = json.loads(response.text)
                return {
                    "optimized_data": proforma_data,  # Keep original data
                    "ai_analysis": optimization_data,
                    "status": "success"
                }
            else:
                raise ValueError("Empty response from AI service")
                
        except Exception as e:
            logging.error(f"AI optimization error: {e}")
            # Fallback optimization logic
            optimized = {}
            suggestions = []
            
            for key, value in proforma_data.items():
                if isinstance(value, (int, float)) and value > 0:
                    # Simple optimization: suggest 10% improvement
                    optimized[key] = round(value * 1.1, 2)
                    suggestions.append({
                        "parameter": key,
                        "current_value": value,
                        "suggested_value": optimized[key],
                        "change_percentage": 10.0,
                        "rationale": f"Suggested 10% improvement in {key} based on general optimization principles.",
                        "impact_description": "This conservative improvement could enhance overall financial performance."
                    })
                else:
                    optimized[key] = value
            
            return {
                "optimized_data": optimized,
                "ai_analysis": {
                    "overall_assessment": "AI service temporarily unavailable. Showing basic optimization suggestions.",
                    "suggestions": suggestions,
                    "risk_analysis": "Unable to perform detailed risk analysis at this time.",
                    "confidence_score": 0.3
                },
                "status": "fallback",
                "error": str(e)
            }

class FinancialEducationService:
    """Service for financial education and explanations"""
    
    @staticmethod
    async def explain_financial_term(term: str) -> str:
        """
        Explain financial terms and concepts
        """
        try:
            system_prompt = """You are a financial education expert. Provide clear, concise explanations of financial terms and concepts.
            Make your explanations accessible to users with varying levels of financial knowledge.
            Include practical examples when helpful."""
            
            prompt = f"Please explain the financial term or concept: {term}"
            
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=[
                    types.Content(role="user", parts=[types.Part(text=prompt)])
                ],
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    temperature=0.5,
                    max_output_tokens=500
                )
            )
            
            return response.text or f"Unable to explain '{term}' at this time."
            
        except Exception as e:
            logging.error(f"Financial education error: {e}")
            return f"Sorry, I'm unable to explain '{term}' right now. Please try again later."
