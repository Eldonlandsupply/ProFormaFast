import json
from typing import Dict, List, Any, Optional

def generate_model_from_inputs(user_inputs: Dict[str, Dict[str, Any]], cell_mappings: List[Dict[str, str]]) -> Dict[str, Any]:
    """
    Generates a structured JSON model from user inputs and cell mappings.

    Args:
        user_inputs (dict): A dictionary where keys are input IDs and values
                            are dicts containing 'base', 'best', and 'worst' scenarios.
        cell_mappings (list): A list of dictionaries defining how inputs map to
                              worksheet cells.

    Returns:
        dict: A dictionary representing the complete model with worksheets and cells.
    """
    # Initialize the main structure for our output JSON
    output_model = {"worksheets": []}
    
    # A helper dictionary to quickly find worksheets we've already created
    worksheet_map = {}

    # Define the scenarios we will loop through for each input
    scenarios = ["base", "best", "worst"]
    
    # Map scenario names to their corresponding column letters/cells from the mappings
    scenario_to_cell_key = {
        "base": "base_cell",
        "best": "best_cell",
        "worst": "worst_cell"
    }

    # Process each mapping rule
    for mapping in cell_mappings:
        worksheet_name = mapping["worksheet"]
        input_id = mapping["input_id"]

        # If the worksheet doesn't exist in our output yet, create it
        if worksheet_name not in worksheet_map:
            new_sheet = {"name": worksheet_name, "cells": []}
            output_model["worksheets"].append(new_sheet)
            worksheet_map[worksheet_name] = new_sheet

        # Get the target worksheet from our helper map
        target_sheet = worksheet_map[worksheet_name]

        # Create a cell for each scenario (base, best, worst)
        for scenario in scenarios:
            cell_key = scenario_to_cell_key[scenario]
            
            if cell_key not in mapping:
                # Skip if a mapping for a specific scenario (e.g., 'worst_cell') isn't defined
                continue

            cell_address = mapping[cell_key]
            # Retrieve the specific value from the user_inputs dictionary
            input_value = user_inputs.get(input_id, {}).get(scenario)

            # Create the formula string, e.g., "=INPUTS!starting_customers_base"
            formula_string = f"=INPUTS!{input_id}_{scenario}"

            # Create the cell object
            cell_object = {
                "addr": cell_address,
                "value": input_value,
                "formula": formula_string
            }

            # Add the new cell to the correct worksheet
            target_sheet["cells"].append(cell_object)

    return output_model

class ModelTemplates:
    """Predefined templates for different business models"""
    
    @staticmethod
    def get_saas_template() -> tuple[Dict[str, Dict[str, Any]], List[Dict[str, str]]]:
        """Returns SaaS business model template with inputs and mappings"""
        user_inputs = {
            "starting_customers": {"base": 1000, "best": 1200, "worst": 800},
            "monthly_churn": {"base": 0.05, "best": 0.04, "worst": 0.06},
            "cac": {"base": 50.0, "best": 45.0, "worst": 60.0},
            "monthly_revenue_per_customer": {"base": 100.0, "best": 120.0, "worst": 80.0},
            "monthly_growth_rate": {"base": 0.10, "best": 0.15, "worst": 0.05}
        }
        
        cell_mappings = [
            {
                "input_id": "starting_customers",
                "worksheet": "Assumptions",
                "base_cell": "B2",
                "best_cell": "C2",
                "worst_cell": "D2"
            },
            {
                "input_id": "monthly_churn",
                "worksheet": "Assumptions",
                "base_cell": "B3",
                "best_cell": "C3",
                "worst_cell": "D3"
            },
            {
                "input_id": "cac",
                "worksheet": "Assumptions",
                "base_cell": "B4",
                "best_cell": "C4",
                "worst_cell": "D4"
            },
            {
                "input_id": "monthly_revenue_per_customer",
                "worksheet": "Assumptions",
                "base_cell": "B5",
                "best_cell": "C5",
                "worst_cell": "D5"
            },
            {
                "input_id": "monthly_growth_rate",
                "worksheet": "Assumptions",
                "base_cell": "B6",
                "best_cell": "C6",
                "worst_cell": "D6"
            }
        ]
        
        return user_inputs, cell_mappings
    
    @staticmethod
    def get_real_estate_template() -> tuple[Dict[str, Dict[str, Any]], List[Dict[str, str]]]:
        """Returns real estate investment template with inputs and mappings"""
        user_inputs = {
            "cap_rate": {"base": 0.08, "best": 0.08, "worst": 0.08},
            "noi": {"base": 100000, "best": 120000, "worst": 80000},
            "purchase_price": {"base": 1250000, "best": 1200000, "worst": 1300000},
            "vacancy_rate": {"base": 0.05, "best": 0.03, "worst": 0.08},
            "annual_rent_growth": {"base": 0.03, "best": 0.04, "worst": 0.02}
        }
        
        cell_mappings = [
            {
                "input_id": "cap_rate",
                "worksheet": "Valuation",
                "base_cell": "B2",
                "best_cell": "C2",
                "worst_cell": "D2"
            },
            {
                "input_id": "noi",
                "worksheet": "Valuation",
                "base_cell": "B3",
                "best_cell": "C3",
                "worst_cell": "D3"
            },
            {
                "input_id": "purchase_price",
                "worksheet": "Valuation",
                "base_cell": "B4",
                "best_cell": "C4",
                "worst_cell": "D4"
            },
            {
                "input_id": "vacancy_rate",
                "worksheet": "Assumptions",
                "base_cell": "B2",
                "best_cell": "C2",
                "worst_cell": "D2"
            },
            {
                "input_id": "annual_rent_growth",
                "worksheet": "Assumptions",
                "base_cell": "B3",
                "best_cell": "C3",
                "worst_cell": "D3"
            }
        ]
        
        return user_inputs, cell_mappings

    @staticmethod
    def get_retail_template() -> tuple[Dict[str, Dict[str, Any]], List[Dict[str, str]]]:
        """Returns retail business template with inputs and mappings"""
        user_inputs = {
            "daily_foot_traffic": {"base": 200, "best": 300, "worst": 150},
            "conversion_rate": {"base": 0.15, "best": 0.20, "worst": 0.10},
            "average_transaction": {"base": 35.0, "best": 45.0, "worst": 25.0},
            "cost_of_goods_sold": {"base": 0.60, "best": 0.55, "worst": 0.65},
            "monthly_rent": {"base": 8000, "best": 7500, "worst": 8500}
        }
        
        cell_mappings = [
            {
                "input_id": "daily_foot_traffic",
                "worksheet": "Revenue",
                "base_cell": "B2",
                "best_cell": "C2",
                "worst_cell": "D2"
            },
            {
                "input_id": "conversion_rate",
                "worksheet": "Revenue",
                "base_cell": "B3",
                "best_cell": "C3",
                "worst_cell": "D3"
            },
            {
                "input_id": "average_transaction",
                "worksheet": "Revenue",
                "base_cell": "B4",
                "best_cell": "C4",
                "worst_cell": "D4"
            },
            {
                "input_id": "cost_of_goods_sold",
                "worksheet": "Expenses",
                "base_cell": "B2",
                "best_cell": "C2",
                "worst_cell": "D2"
            },
            {
                "input_id": "monthly_rent",
                "worksheet": "Expenses",
                "base_cell": "B3",
                "best_cell": "C3",
                "worst_cell": "D3"
            }
        ]
        
        return user_inputs, cell_mappings

def create_custom_model(template_type: str, custom_inputs: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    """
    Create a financial model using predefined templates or custom inputs
    
    Args:
        template_type: Type of business model ('saas', 'real_estate', 'retail')
        custom_inputs: Optional custom user inputs to override template defaults
    
    Returns:
        Complete financial model as JSON structure
    """
    # Get the appropriate template
    if template_type.lower() == 'saas':
        user_inputs, cell_mappings = ModelTemplates.get_saas_template()
    elif template_type.lower() == 'real_estate':
        user_inputs, cell_mappings = ModelTemplates.get_real_estate_template()
    elif template_type.lower() == 'retail':
        user_inputs, cell_mappings = ModelTemplates.get_retail_template()
    else:
        raise ValueError(f"Unknown template type: {template_type}")
    
    # Override with custom inputs if provided
    if custom_inputs:
        user_inputs.update(custom_inputs)
    
    # Generate the model
    return generate_model_from_inputs(user_inputs, cell_mappings)

# Example usage and testing
if __name__ == "__main__":
    # Test SaaS model generation
    saas_model = create_custom_model('saas')
    print("SaaS Model:")
    print(json.dumps(saas_model, indent=2))
    
    print("\n" + "="*50 + "\n")
    
    # Test Real Estate model generation
    real_estate_model = create_custom_model('real_estate')
    print("Real Estate Model:")
    print(json.dumps(real_estate_model, indent=2))