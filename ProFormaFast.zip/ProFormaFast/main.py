from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import json
import os
import datetime
import logging
import database as db
from ai_service import FinancialAnalysisService, FinancialEducationService
from model_generator import create_custom_model, generate_model_from_inputs

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Pro Forma AI Financial Assistant", version="2.0.0")

# Mount static files and define routes for HTML pages
app.mount("/static", StaticFiles(directory="static", html=True), name="static")

@app.get("/")
@app.get("/index.html")
async def serve_index():
    return FileResponse(os.path.join("static", "index.html"))

@app.get("/chatbot.html")
async def serve_chatbot():
    return FileResponse(os.path.join("static", "chatbot.html"))

async def get_current_user(request: Request) -> int:
    """Dependency to extract, validate, and return the user ID from a bearer token."""
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    token = auth_header.split(" ", 1)[1]
    conn = await db.get_db_connection()
    conn.row_factory = db.aiosqlite.Row
    try:
        cursor = await conn.execute("SELECT user_id, expires_at FROM tokens WHERE token = ?", (token,))
        row = await cursor.fetchone()

        if row is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

        expires_at = datetime.datetime.fromisoformat(row["expires_at"])
        if expires_at < datetime.datetime.utcnow():
            await conn.execute("DELETE FROM tokens WHERE token = ?", (token,))
            await conn.commit()
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token has expired")

        return row["user_id"]
    finally:
        await conn.close()

async def get_subscription(user_id: int) -> str:
    """Retrieve the subscription level for a given user."""
    conn = await db.get_db_connection()
    conn.row_factory = db.aiosqlite.Row
    try:
        cursor = await conn.execute("SELECT subscription FROM users WHERE id = ?", (user_id,))
        row = await cursor.fetchone()
        return row["subscription"] if row else "free"
    finally:
        await conn.close()

async def require_paid_subscription(user_id: int = Depends(get_current_user)) -> int:
    """Dependency that requires a paid subscription for AI features."""
    subscription = await get_subscription(user_id)
    if subscription == "free":
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="This feature requires a paid subscription. Please upgrade to access AI-powered financial analysis."
        )
    return user_id

@app.post("/register")
async def register(payload: dict):
    username = payload.get("username")
    password = payload.get("password")
    if not username or not password:
        raise HTTPException(status_code=400, detail="Username and password are required")
    hashed_password = db.hash_password(password)
    conn = await db.get_db_connection()
    conn.row_factory = db.aiosqlite.Row
    try:
        cursor = await conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        await conn.commit()
        return {"message": "User created successfully", "user_id": cursor.lastrowid}
    except db.aiosqlite.IntegrityError:
        raise HTTPException(status_code=409, detail="Username already exists")
    finally:
        await conn.close()

@app.post("/login")
async def login(payload: dict):
    username = payload.get("username")
    password = payload.get("password")
    if not username or not password:
        raise HTTPException(status_code=400, detail="Username and password are required")
    conn = await db.get_db_connection()
    conn.row_factory = db.aiosqlite.Row
    try:
        cursor = await conn.execute("SELECT id, password FROM users WHERE username = ?", (username,))
        user = await cursor.fetchone()
        if user and db.verify_password(password, user["password"]):
            token = await db.create_token(conn, user["id"])
            return {"token": token, "token_type": "bearer"}
        raise HTTPException(status_code=401, detail="Invalid username or password")
    finally:
        await conn.close()

@app.post("/upgrade")
async def upgrade_subscription(user_id: int = Depends(get_current_user)):
    """Upgrade user to paid subscription (simplified for demo)"""
    conn = await db.get_db_connection()
    conn.row_factory = db.aiosqlite.Row
    try:
        await conn.execute("UPDATE users SET subscription = 'paid' WHERE id = ?", (user_id,))
        await conn.commit()
        return {"message": "Successfully upgraded to paid subscription", "subscription": "paid"}
    finally:
        await conn.close()

@app.get("/subscription")
async def get_user_subscription(user_id: int = Depends(get_current_user)):
    """Get current user subscription status"""
    subscription = await get_subscription(user_id)
    return {"subscription": subscription}

@app.post("/proformas")
async def save_proforma(payload: dict, user_id: int = Depends(get_current_user)):
    data = payload.get("data")
    if data is None:
        raise HTTPException(status_code=400, detail="Missing data field")
    json_str = json.dumps(data)

    subscription = await get_subscription(user_id)
    async with await db.get_db() as conn:
        if subscription == "free":
            cursor = await conn.execute("SELECT COUNT(*) as count FROM proformas WHERE user_id = ?", (user_id,))
            row = await cursor.fetchone()
            count = row["count"] if row else 0
            if count >= 1:
                raise HTTPException(status_code=402, detail="Upgrade to save more than one pro forma.")

        created_at = datetime.datetime.utcnow().isoformat()
        cursor = await conn.execute(
            "INSERT INTO proformas (user_id, data, created_at) VALUES (?, ?, ?)",
            (user_id, json_str, created_at),
        )
        await conn.commit()
        return {"message": "Pro forma saved", "id": cursor.lastrowid}

@app.get("/proformas")
async def list_proformas(user_id: int = Depends(get_current_user)):
    async with await db.get_db() as conn:
        cursor = await conn.execute("SELECT id, data, created_at FROM proformas WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
        rows = await cursor.fetchall()
        return [{"id": r["id"], "data": json.loads(r["data"]), "created_at": r["created_at"]} for r in rows]

@app.get("/proformas/{proforma_id}")
async def get_proforma(proforma_id: int, user_id: int = Depends(get_current_user)):
    """Get a specific pro forma by ID"""
    async with await db.get_db() as conn:
        cursor = await conn.execute("SELECT id, data, created_at FROM proformas WHERE id = ? AND user_id = ?", (proforma_id, user_id))
        row = await cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Pro forma not found")
        return {"id": row["id"], "data": json.loads(row["data"]), "created_at": row["created_at"]}

@app.post("/chat")
async def chat(payload: dict, user_id: int = Depends(require_paid_subscription)):
    """AI-powered financial chatbot with context awareness"""
    message = payload.get("message")
    if not message:
        raise HTTPException(status_code=400, detail="Message is required")
    
    try:
        # Get user's pro forma data for context
        async with await db.get_db() as conn:
            cursor = await conn.execute("SELECT id, data, created_at FROM proformas WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
            rows = await cursor.fetchall()
            user_proformas = [{"id": r["id"], "data": json.loads(r["data"]), "created_at": r["created_at"]} for r in rows]
        
        # Get AI response with context
        ai_response = await FinancialAnalysisService.chat_with_context(message, user_proformas)
        
        return {
            "reply": ai_response,
            "context_used": len(user_proformas) > 0,
            "proformas_count": len(user_proformas)
        }
    
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail="Failed to process chat request")

@app.post("/optimize/{proforma_id}")
async def optimize_proforma(proforma_id: int, user_id: int = Depends(require_paid_subscription)):
    """AI-powered pro forma optimization with detailed analysis"""
    try:
        # Get the pro forma data
        async with await db.get_db() as conn:
            cursor = await conn.execute("SELECT data FROM proformas WHERE id = ? AND user_id = ?", (proforma_id, user_id))
            row = await cursor.fetchone()
            
            if not row:
                raise HTTPException(status_code=404, detail="Pro forma not found")
            
            proforma_data = json.loads(row["data"])
        
        # Get AI optimization
        optimization_result = await FinancialAnalysisService.optimize_proforma(proforma_data)
        
        return optimization_result
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Optimization error: {e}")
        raise HTTPException(status_code=500, detail="Failed to optimize pro forma")

@app.post("/explain")
async def explain_financial_term(payload: dict, user_id: int = Depends(require_paid_subscription)):
    """Explain financial terms and concepts"""
    term = payload.get("term")
    if not term:
        raise HTTPException(status_code=400, detail="Term is required")
    
    try:
        explanation = await FinancialEducationService.explain_financial_term(term)
        return {"term": term, "explanation": explanation}
    
    except Exception as e:
        logger.error(f"Explanation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to explain term")

@app.post("/generate-model")
async def generate_financial_model(payload: dict, user_id: int = Depends(get_current_user)):
    """Generate a structured financial model from business inputs"""
    try:
        template_type = payload.get("template_type", "saas")
        custom_inputs = payload.get("custom_inputs", {})
        
        # Generate the financial model
        model = create_custom_model(template_type, custom_inputs)
        
        # Save the generated model as a pro forma for the user
        model_data = {
            "model_type": template_type,
            "generated_model": model,
            "custom_inputs": custom_inputs
        }
        
        conn = await db.get_db_connection()
        conn.row_factory = db.aiosqlite.Row
        try:
            created_at = datetime.datetime.utcnow().isoformat()
            cursor = await conn.execute(
                "INSERT INTO proformas (user_id, data, created_at) VALUES (?, ?, ?)",
                (user_id, json.dumps(model_data), created_at),
            )
            await conn.commit()
            
            return {
                "message": "Financial model generated successfully",
                "model_id": cursor.lastrowid,
                "model": model,
                "template_type": template_type
            }
        finally:
            await conn.close()
            
    except Exception as e:
        logger.error(f"Model generation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate financial model")

@app.post("/custom-model")
async def create_custom_financial_model(payload: dict, user_id: int = Depends(get_current_user)):
    """Create a completely custom financial model from user-defined inputs and mappings"""
    try:
        user_inputs = payload.get("user_inputs", {})
        cell_mappings = payload.get("cell_mappings", [])
        
        if not user_inputs or not cell_mappings:
            raise HTTPException(status_code=400, detail="Both user_inputs and cell_mappings are required")
        
        # Generate the custom model
        model = generate_model_from_inputs(user_inputs, cell_mappings)
        
        # Save the generated model
        model_data = {
            "model_type": "custom",
            "generated_model": model,
            "user_inputs": user_inputs,
            "cell_mappings": cell_mappings
        }
        
        conn = await db.get_db_connection()
        conn.row_factory = db.aiosqlite.Row
        try:
            created_at = datetime.datetime.utcnow().isoformat()
            cursor = await conn.execute(
                "INSERT INTO proformas (user_id, data, created_at) VALUES (?, ?, ?)",
                (user_id, json.dumps(model_data), created_at),
            )
            await conn.commit()
            
            return {
                "message": "Custom financial model created successfully",
                "model_id": cursor.lastrowid,
                "model": model
            }
        finally:
            await conn.close()
            
    except Exception as e:
        logger.error(f"Custom model creation error: {e}")
        raise HTTPException(status_code=500, detail="Failed to create custom financial model")

@app.get("/model-templates")
async def get_available_templates(user_id: int = Depends(get_current_user)):
    """Get available financial model templates"""
    templates = {
        "saas": {
            "name": "SaaS Business",
            "description": "Subscription-based software business model with customer acquisition, churn, and recurring revenue",
            "inputs": ["starting_customers", "monthly_churn", "cac", "monthly_revenue_per_customer", "monthly_growth_rate"]
        },
        "real_estate": {
            "name": "Real Estate Investment",
            "description": "Property investment model with cap rates, NOI, and valuation analysis",
            "inputs": ["cap_rate", "noi", "purchase_price", "vacancy_rate", "annual_rent_growth"]
        },
        "retail": {
            "name": "Retail Business",
            "description": "Physical retail business with foot traffic, conversion rates, and transaction analysis",
            "inputs": ["daily_foot_traffic", "conversion_rate", "average_transaction", "cost_of_goods_sold", "monthly_rent"]
        }
    }
    
    return {"templates": templates}

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.datetime.utcnow().isoformat()}

# Initialize the database on startup
@app.on_event("startup")
async def startup_event():
    await db.init_db()
    logger.info("Pro Forma AI application started successfully")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
