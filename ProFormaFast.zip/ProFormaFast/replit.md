# Overview

The Pro Forma AI Financial Assistant is a comprehensive web application that provides AI-powered financial analysis, planning tools, and structured financial model generation. Users can create, store, and analyze pro forma financial statements with the assistance of an intelligent chatbot powered by Google's Gemini AI. The application now includes advanced financial model generation capabilities with predefined templates for different business types (SaaS, Real Estate, Retail). The application offers subscription-based access to advanced AI features, with free users having limited functionality and paid subscribers accessing the full suite of AI-powered financial analysis tools.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend uses vanilla HTML, CSS, and JavaScript with a modern, responsive design. The architecture consists of:
- **Static file serving**: FastAPI serves HTML pages directly from the `/static` directory
- **Single-page applications**: Separate HTML files for the main dashboard (`index.html`) and AI chat interface (`chatbot.html`)
- **Client-side authentication**: Bearer token-based authentication handled via JavaScript with localStorage persistence
- **Responsive design**: CSS Grid and Flexbox layouts with gradient backgrounds and glassmorphism effects

## Backend Architecture
The backend is built with FastAPI using an asynchronous architecture:
- **FastAPI framework**: Provides async REST API endpoints with automatic OpenAPI documentation
- **Async SQLite database**: Uses `aiosqlite` for non-blocking database operations
- **Dependency injection**: FastAPI's dependency system for authentication and database connections
- **Modular service layer**: Separate services for AI operations (`ai_service.py`) and database operations (`database.py`)

## Authentication and Authorization
The system implements a custom token-based authentication system:
- **Password hashing**: Uses hashlib with a secret salt for secure password storage
- **Token management**: Session tokens with expiration times stored in the database
- **Bearer token authentication**: HTTP Authorization header validation for API access
- **Subscription-based access control**: Different feature access levels based on user subscription tier (free vs paid)

## Data Storage
The application uses SQLite as the primary database:
- **Async SQLite**: Non-blocking database operations using `aiosqlite`
- **Three main tables**: Users, authentication tokens, and pro forma documents
- **JSON storage**: Pro forma data stored as JSON text in the database
- **Automatic initialization**: Database schema created on application startup

## AI Integration Architecture
The AI functionality is powered by Google's Gemini API:
- **Gemini client**: Direct integration with Google's genai library
- **Structured responses**: Pydantic models for type-safe AI response parsing
- **Context-aware chat**: AI chatbot that can reference user's stored pro forma data
- **Financial optimization**: AI-powered analysis and suggestions for financial improvements
- **Subscription gating**: Premium AI features restricted to paid subscribers

## Financial Model Generation Architecture
The application includes a sophisticated model generation system:
- **Template-based generation**: Predefined templates for SaaS, Real Estate, and Retail businesses
- **Custom model creation**: Support for user-defined inputs and cell mappings
- **Structured output**: Generates JSON models with worksheet and cell structures
- **Excel-compatible formulas**: Creates formulas that reference input data appropriately
- **Scenario modeling**: Supports base, best, and worst-case scenario generation

## API Design Patterns
The REST API follows standard conventions:
- **RESTful endpoints**: Standard HTTP methods for CRUD operations
- **JSON communication**: All API requests and responses use JSON format
- **Error handling**: Consistent HTTP status codes and error message structure
- **Authentication middleware**: Centralized token validation using FastAPI dependencies
- **Static file serving**: Direct file serving for frontend assets
- **Model generation endpoints**: Specialized endpoints for financial model creation and template management

The architecture prioritizes simplicity and maintainability while providing a scalable foundation for AI-powered financial analysis and model generation features.

# External Dependencies

## AI Services
- **Google Gemini API**: Primary AI service for natural language processing and financial analysis
  - Requires `GEMINI_API_KEY` environment variable
  - Used for intelligent chatbot conversations and pro forma optimization suggestions

## Development Framework
- **FastAPI**: Modern Python web framework for building APIs with automatic documentation
- **Pydantic**: Data validation and serialization using Python type annotations
- **aiosqlite**: Asynchronous SQLite database driver for non-blocking database operations

## Frontend Dependencies
- **Vanilla JavaScript**: No external frontend frameworks, uses native browser APIs
- **CSS Grid/Flexbox**: Modern CSS layout systems for responsive design

## Security Dependencies
- **Python hashlib**: Built-in library for password hashing and token generation
- **Python secrets**: Cryptographically secure random number generation for tokens

## Environment Configuration
- **SECRET_SALT**: Environment variable required for secure password hashing
- **GEMINI_API_KEY**: Environment variable for Google Gemini API authentication

## Database
- **SQLite**: Embedded database for development and small-scale deployment
- **File-based storage**: Database stored as `database.db` file in the project root

Note: The application is designed to be easily deployable on Replit with minimal configuration requirements, using only standard Python libraries and the Google Gemini API service.